import { test, expect, request } from '@playwright/test';

/**
 * Test Suite: ReqBin API Testing
 * Target: https://reqbin.com/echo/post/json
 * Format: { "Id": 78912, "Customer": "Jason Sweet", "Quantity": 1, "Price": 18.00 }
 */

const API_URL = 'https://reqbin.com/echo/post/json';

const BASE_PAYLOAD = {
  Id: 78912,
  Customer: 'Jason Sweet',
  Quantity: 1,
  Price: 18.00,
};

// ReqBin memerlukan header browser agar tidak diblokir (403)
const BROWSER_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'Origin': 'https://reqbin.com',
  'Referer': 'https://reqbin.com/',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'X-Requested-With': 'XMLHttpRequest',
};

// ─────────────────────────────────────────────────────────────────────────────
// TC-API-001 ~ 010: Positive Tests
// ─────────────────────────────────────────────────────────────────────────────
test.describe('ReqBin API — POST /echo/post/json', () => {

  test('TC-API-001: POST dengan payload valid mengembalikan status 200', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: BASE_PAYLOAD,
    });
    expect(res.status()).toBe(200);
    await ctx.dispose();
  });

  test('TC-API-002: Response Content-Type adalah application/json', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: BASE_PAYLOAD,
    });
    expect(res.headers()['content-type']).toContain('application/json');
    await ctx.dispose();
  });

  test('TC-API-003: Response body adalah JSON yang valid (parseable)', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: BASE_PAYLOAD,
    });
    const body = await res.json();
    expect(typeof body).toBe('object');
    await ctx.dispose();
  });

  test('TC-API-004: Response body mengandung field "success"', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: BASE_PAYLOAD,
    });
    const body = await res.json();
    expect(body).toHaveProperty('success');
    await ctx.dispose();
  });

  test('TC-API-005: Field "success" bernilai "true"', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: BASE_PAYLOAD,
    });
    const body = await res.json();
    // ReqBin echo API mengembalikan { "success": "true" } (string)
    expect(String(body.success)).toBe('true');
    await ctx.dispose();
  });

  test('TC-API-006: POST dengan Id berbeda tetap mengembalikan 200', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Id: 99999 },
    });
    expect(res.status()).toBe(200);
    await ctx.dispose();
  });

  test('TC-API-007: POST dengan Customer name berbeda tetap mengembalikan 200', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Customer: 'Budi Santoso' },
    });
    expect(res.status()).toBe(200);
    await ctx.dispose();
  });

  test('TC-API-008: POST dengan Quantity lebih besar tetap mengembalikan 200', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Quantity: 100 },
    });
    expect(res.status()).toBe(200);
    await ctx.dispose();
  });

  test('TC-API-009: POST dengan Price desimal tetap mengembalikan 200', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Price: 99.99 },
    });
    expect(res.status()).toBe(200);
    await ctx.dispose();
  });

  test('TC-API-010: Response time tidak lebih dari 5 detik', async () => {
    const ctx = await request.newContext();
    const start = Date.now();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: BASE_PAYLOAD,
    });
    const duration = Date.now() - start;
    expect(res.status()).toBe(200);
    expect(duration).toBeLessThan(5000);
    await ctx.dispose();
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-API-011 ~ 015: Edge Cases & Negative Tests
  // ─────────────────────────────────────────────────────────────────────────

  test('TC-API-011: POST dengan extra field tidak menyebabkan error', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, ExtraField: 'test', Notes: 'unit test' },
    });
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });

  test('TC-API-012: POST dengan payload kosong tidak crash server (bukan 5xx)', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: {},
    });
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });

  test('TC-API-013: POST dengan Price = 0 tidak menyebabkan server error', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Price: 0 },
    });
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });

  test('TC-API-014: POST dengan Quantity = 0 tidak menyebabkan server error', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Quantity: 0 },
    });
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });

  test('TC-API-015: POST dengan Customer string panjang tidak crash server', async () => {
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, {
      headers: BROWSER_HEADERS,
      data: { ...BASE_PAYLOAD, Customer: 'A'.repeat(200) },
    });
    expect(res.status()).toBeLessThan(500);
    await ctx.dispose();
  });
});
