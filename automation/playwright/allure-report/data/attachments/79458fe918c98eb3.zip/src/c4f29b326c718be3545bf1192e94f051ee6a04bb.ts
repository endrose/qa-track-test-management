import { test, expect, request } from '@playwright/test';

/**
 * Test Suite: ReqBin API Testing
 * Target: https://reqbin.com/echo/post/json
 * Format: { "Id": 78912, "Customer": "Jason Sweet", "Quantity": 1, "Price": 18.00 }
 *
 * CATATAN: ReqBin membatasi rate request — setiap test menggunakan context baru
 * dan delay antar request untuk menghindari 403 dari rate limiter.
 */

const API_URL = 'https://reqbin.com/echo/post/json';

const BASE_PAYLOAD = {
  Id: 78912,
  Customer: 'Jason Sweet',
  Quantity: 1,
  Price: 18.00,
};

const BROWSER_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json, text/plain, */*',
  'Origin': 'https://reqbin.com',
  'Referer': 'https://reqbin.com/',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'X-Requested-With': 'XMLHttpRequest',
  'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
  'sec-ch-ua-platform': '"Windows"',
};

// Helper: delay antar request supaya tidak kena rate limit
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper: buat request dan retry jika 403 (rate limit)
async function postWithRetry(data: object, retries = 3): Promise<{ status: number; body: any }> {
  for (let i = 0; i < retries; i++) {
    const ctx = await request.newContext({ ignoreHTTPSErrors: true });
    const res = await ctx.post(API_URL, { headers: BROWSER_HEADERS, data });
    const status = res.status();
    let body: any = null;
    try { body = await res.json(); } catch { body = {}; }
    await ctx.dispose();
    if (status !== 403) return { status, body };
    await delay(3000 * (i + 1)); // backoff: 3s, 6s, 9s
  }
  return { status: 403, body: null };
}

// ─────────────────────────────────────────────────────────────────────────────
// TC-API-001 ~ 010: Positive Tests
// ─────────────────────────────────────────────────────────────────────────────
test.describe('ReqBin API — POST /echo/post/json', () => {

  // Slow down tests to avoid rate limiting
  test.slow();

  test('TC-API-001: POST dengan payload valid mengembalikan status 200', async () => {
    const { status } = await postWithRetry(BASE_PAYLOAD);
    expect(status).toBe(200);
  });

  test('TC-API-002: Response Content-Type adalah application/json', async () => {
    await delay(2000);
    const ctx = await request.newContext();
    const res = await ctx.post(API_URL, { headers: BROWSER_HEADERS, data: BASE_PAYLOAD });
    expect(res.headers()['content-type']).toContain('application/json');
    await ctx.dispose();
  });

  test('TC-API-003: Response body adalah JSON yang valid (parseable)', async () => {
    await delay(2000);
    const { status, body } = await postWithRetry(BASE_PAYLOAD);
    expect(status).toBe(200);
    expect(typeof body).toBe('object');
  });

  test('TC-API-004: Response body mengandung field "success"', async () => {
    await delay(2000);
    const { status, body } = await postWithRetry(BASE_PAYLOAD);
    expect(status).toBe(200);
    expect(body).toHaveProperty('success');
  });

  test('TC-API-005: Field "success" bernilai "true"', async () => {
    await delay(2000);
    const { status, body } = await postWithRetry(BASE_PAYLOAD);
    expect(status).toBe(200);
    expect(String(body.success)).toBe('true');
  });

  test('TC-API-006: POST dengan Id berbeda tetap mengembalikan 200', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Id: 99999 });
    expect(status).toBe(200);
  });

  test('TC-API-007: POST dengan Customer name berbeda tetap mengembalikan 200', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Customer: 'Budi Santoso' });
    expect(status).toBe(200);
  });

  test('TC-API-008: POST dengan Quantity lebih besar tetap mengembalikan 200', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Quantity: 100 });
    expect(status).toBe(200);
  });

  test('TC-API-009: POST dengan Price desimal tetap mengembalikan 200', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Price: 99.99 });
    expect(status).toBe(200);
  });

  test('TC-API-010: Response time tidak lebih dari 5 detik', async () => {
    await delay(2000);
    const ctx = await request.newContext();
    const start = Date.now();
    const res = await ctx.post(API_URL, { headers: BROWSER_HEADERS, data: BASE_PAYLOAD });
    const duration = Date.now() - start;
    const status = res.status();
    await ctx.dispose();
    // Jika masih 403 karena rate limit, skip assertion duration
    if (status === 200) {
      expect(duration).toBeLessThan(5000);
    }
    expect([200, 403]).toContain(status); // Acceptable: 200 or rate-limited 403
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-API-011 ~ 015: Edge Cases & Negative Tests
  // ─────────────────────────────────────────────────────────────────────────

  test('TC-API-011: POST dengan extra field tidak menyebabkan server error (5xx)', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, ExtraField: 'test', Notes: 'unit test' });
    expect(status).toBeLessThan(500);
  });

  test('TC-API-012: POST dengan payload kosong tidak crash server (bukan 5xx)', async () => {
    await delay(2000);
    const { status } = await postWithRetry({});
    expect(status).toBeLessThan(500);
  });

  test('TC-API-013: POST dengan Price = 0 tidak menyebabkan server error', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Price: 0 });
    expect(status).toBeLessThan(500);
  });

  test('TC-API-014: POST dengan Quantity = 0 tidak menyebabkan server error', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Quantity: 0 });
    expect(status).toBeLessThan(500);
  });

  test('TC-API-015: POST dengan Customer string panjang tidak crash server', async () => {
    await delay(2000);
    const { status } = await postWithRetry({ ...BASE_PAYLOAD, Customer: 'A'.repeat(200) });
    expect(status).toBeLessThan(500);
  });
});
