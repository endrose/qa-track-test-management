import { test, expect } from '@playwright/test';

test.describe("Website Sauce", () => {
  test("Verifikasi Halaman Sauce", async ({ page }) => {
    // Navigate to URL
    await page.goto("https://www.saucedemo.com/");

    // Fill "[name="user-name"]" with value
    await page.getByTestId("[name=\"user-name\"]").fill("standard_user");

    // Fill "[name="password"]" with value
    await page.getByTestId("[name=\"password\"]").fill("secret_sauce");

    // Click element
    await page.getByTestId("#login-button").click();

    // Assert element is visible
    await expect(page.locator("//*[@id=\"header_container\"]/div[1]/div[2]/div")).toBeVisible();

  });
});