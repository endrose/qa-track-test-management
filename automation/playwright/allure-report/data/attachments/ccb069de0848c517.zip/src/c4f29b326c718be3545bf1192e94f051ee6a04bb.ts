import { test, expect } from '@playwright/test';

/**
 * Test Suite: ReqBin API Testing — menggunakan browser context penuh
 * Target: https://reqbin.com/echo/post/json
 * Format: { "Id": 78912, "Customer": "Jason Sweet", "Quantity": 1, "Price": 18.00 }
 *
 * Pendekatan: page.evaluate() untuk menjalankan fetch dari dalam browser,
 * sehingga session cookies & CSRF token otomatis terbawa (bypass bot protection).
 */

const API_URL = 'https://reqbin.com/echo/post/json';

const BASE_PAYLOAD = {
  Id: 78912,
  Customer: 'Jason Sweet',
  Quantity: 1,
  Price: 18.00,
};

/**
 * Helper: kirim POST dari dalam browser context (memiliki cookies asli)
 */
async function postFromBrowser(page: any, data: object): Promise<{ status: number; body: any }> {
  return page.evaluate(async ({ url, payload }: { url: string; payload: object }) => {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(payload),
    });
    let body: any = null;
    try { body = await res.json(); } catch { body = {}; }
    return { status: res.status, body };
  }, { url: API_URL, payload: data });
}

test.describe('ReqBin API — POST /echo/post/json', () => {
  // Setiap test menggunakan browser yang sudah visit halaman reqbin untuk mendapat session
  test.beforeEach(async ({ page }) => {
    await page.goto('https://reqbin.com', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(1500); // tunggu session cookie terbentuk
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-API-001 ~ 010: Positive Tests
  // ─────────────────────────────────────────────────────────────────────────

  test('TC-API-001: POST dengan payload valid mengembalikan status 200', async ({ page }) => {
    const { status } = await postFromBrowser(page, BASE_PAYLOAD);
    expect(status).toBe(200);
  });

  test('TC-API-002: Response Content-Type adalah application/json', async ({ page }) => {
    const res = await page.evaluate(async ({ url, payload }: { url: string; payload: object }) => {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload),
      });
      return { status: r.status, contentType: r.headers.get('content-type') };
    }, { url: API_URL, payload: BASE_PAYLOAD });
    expect(res.status).toBe(200);
    expect(res.contentType).toContain('application/json');
  });

  test('TC-API-003: Response body adalah JSON yang valid (parseable)', async ({ page }) => {
    const { status, body } = await postFromBrowser(page, BASE_PAYLOAD);
    expect(status).toBe(200);
    expect(typeof body).toBe('object');
    expect(body).not.toBeNull();
  });

  test('TC-API-004: Response body mengandung field "success"', async ({ page }) => {
    const { status, body } = await postFromBrowser(page, BASE_PAYLOAD);
    expect(status).toBe(200);
    expect(body).toHaveProperty('success');
  });

  test('TC-API-005: Field "success" bernilai "true"', async ({ page }) => {
    const { status, body } = await postFromBrowser(page, BASE_PAYLOAD);
    expect(status).toBe(200);
    // ReqBin echo mengembalikan { "success": "true" } sebagai string
    expect(String(body.success)).toBe('true');
  });

  test('TC-API-006: POST dengan Id berbeda tetap mengembalikan 200', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Id: 99999 });
    expect(status).toBe(200);
  });

  test('TC-API-007: POST dengan Customer name berbeda tetap mengembalikan 200', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Customer: 'Budi Santoso' });
    expect(status).toBe(200);
  });

  test('TC-API-008: POST dengan Quantity lebih besar tetap mengembalikan 200', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Quantity: 100 });
    expect(status).toBe(200);
  });

  test('TC-API-009: POST dengan Price desimal tetap mengembalikan 200', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Price: 99.99 });
    expect(status).toBe(200);
  });

  test('TC-API-010: Response time tidak lebih dari 5 detik', async ({ page }) => {
    const result = await page.evaluate(async ({ url, payload }: { url: string; payload: object }) => {
      const start = Date.now();
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload),
      });
      return { status: r.status, duration: Date.now() - start };
    }, { url: API_URL, payload: BASE_PAYLOAD });
    expect(result.status).toBe(200);
    expect(result.duration).toBeLessThan(5000);
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-API-011 ~ 015: Edge Cases & Negative Tests
  // ─────────────────────────────────────────────────────────────────────────

  test('TC-API-011: POST dengan extra field tidak menyebabkan server error (5xx)', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, ExtraField: 'test', Notes: 'unit test' });
    expect(status).toBeLessThan(500);
  });

  test('TC-API-012: POST dengan payload kosong tidak crash server (bukan 5xx)', async ({ page }) => {
    const { status } = await postFromBrowser(page, {});
    expect(status).toBeLessThan(500);
  });

  test('TC-API-013: POST dengan Price = 0 tidak menyebabkan server error', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Price: 0 });
    expect(status).toBeLessThan(500);
  });

  test('TC-API-014: POST dengan Quantity = 0 tidak menyebabkan server error', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Quantity: 0 });
    expect(status).toBeLessThan(500);
  });

  test('TC-API-015: POST dengan Customer string panjang tidak crash server', async ({ page }) => {
    const { status } = await postFromBrowser(page, { ...BASE_PAYLOAD, Customer: 'A'.repeat(200) });
    expect(status).toBeLessThan(500);
  });
});
