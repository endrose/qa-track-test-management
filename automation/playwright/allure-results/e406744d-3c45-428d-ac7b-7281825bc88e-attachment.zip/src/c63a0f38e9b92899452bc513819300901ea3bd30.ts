import { test, expect } from '@playwright/test';

test.describe("Website Sauce", () => {
  test("Verifikasi Login & Halaman Sauce", async ({ page }) => {
    // Navigate to URL
    await page.goto("https://www.saucedemo.com/");

    // Fill "user-name" with value
    await page.getByTestId("user-name").fill("standard_user");

    // Fill "password" with value
    await page.getByTestId("password").fill("secret_sauce");

    // Click element
    await page.getByTestId("login-button").click();

    // Navigate to URL
    await page.goto("https://www.saucedemo.com/inventory.html");

  });
});